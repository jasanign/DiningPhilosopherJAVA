/**
 * Philosopher Interface
 * @author Dr. Kreahling
 *
 */
public interface PhilosopherInterface {
	/** Number of diner */
	public static final int DINERS = 5 ;
	public void takeChopsticks(int i) ;
	public void replaceChopsticks(int i) ;

}
